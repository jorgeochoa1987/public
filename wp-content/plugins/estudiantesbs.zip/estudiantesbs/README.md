PLugin para estudiantes
